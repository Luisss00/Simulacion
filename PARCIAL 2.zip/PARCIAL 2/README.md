 Justificación 

1. Cambio de Lógica: Movimiento Global vs. Local 
●	Código Base: El código original solía mover al personaje en los ejes fijos del mundo (X, Y, Z). Si el personaje giraba, las teclas seguían moviéndolo en la misma dirección cardinal. 

●	Nuevo Código: Se implementó una matriz de rotación $R_z(\theta)$. Esto permite que el movimiento sea relativo a la orientación del humanoide. Ahora, adelante siempre es hacia donde mira el personaje, calculado mediante el producto matricial $P_{nueva} = P_{vieja} + R_z(\theta) \cdot d_{local}$. 


2. Implementación de Álgebra Lineal Formal 
●	Código Base: Utilizaba cálculos aritméticos simples o funciones básicas de la librería math. 

●	Nuevo Código: Se integró la librería Sympy para el manejo de matrices. La creación de la función calcular_Rz(angulo) centraliza el modelo matemático, asegurando que tanto la traslación como el anclaje de objetos utilicen el mismo marco de referencia. 


3. Sistema de Anclaje de Objetos (Vínculo Cinemático) 
●	Código Base: No existía interacción con objetos externos; la botella era un elemento estático en el entorno. 

●	Nuevo Código: Se creó la función anclar_botella(), la cual funciona como un padre virtual. En cada paso de la simulación, el código calcula la posición exacta de la mano derecha del humanoide aplicando un offset (desfase) al vector de posición del personaje. Esto garantiza que la botella siga al humano incluso durante las rotaciones. 


4. Robustez y Sincronización 
●	Código Base: Los objetos podían verse afectados por la física de Webots (gravedad o colisiones), lo que causaba que la botella se cayera si no estaba bien sujeta. 

●	Nuevo Código: Se utiliza resetPhysics() en cada ciclo para anular cualquier velocidad acumulada por la gravedad. Además, al definir la botella con locked TRUE en el archivo .wbt y controlarla por Supervisor, se asegura que el script tenga prioridad absoluta sobre el motor de física del simulador. 

5. Optimización de Identificadores (Nombres DEF) 


●	Código Base: Generalmente usaba nombres genéricos que podían causar errores de referencia. 

●	Nuevo Código: Se estandarizaron los nombres de los nodos a pedestrian1 y beerbottle. Esto permite que la función getFromDef localice los objetos de manera instantánea, estableciendo un puente de comunicación directo entre el controlador Python y el mundo 3D. 


